const 배열 = ["예병수", "류제천", "이재상", "최원장"];

for (let i = 0; i < 배열.length; i++) {
    배열[i] = 배열[i] + " 튜터";
}

console.log(배열);